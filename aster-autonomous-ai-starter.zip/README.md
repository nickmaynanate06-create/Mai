# Aster — Autonomous AI Starter

A phone-friendly Progressive Web App (PWA) for a personal AI agent with:
- Persistent browser memory (IndexedDB/localStorage fallback; stays on this device/browser)
- Goal decomposition into editable plans
- Explicit, allow-listed tools
- User-controlled autonomy and confirmation gates
- A FastAPI backend adapter for an LLM provider (API key stays server-side)
- A visible activity log and stop/pause controls

## Important limitations
This is a starter project, not a conscious or unconstrained AI. It plans and executes only through tools you explicitly enable. It does not run continuously in the background, bypass Android permissions, or execute arbitrary shell/code. Browser memory is local to this browser unless you configure a database/backend.

## Run on your phone or computer
You can open `web/index.html` directly for the offline demo. For installable PWA behavior, serve the `web/` directory over HTTPS (or localhost). GitHub Pages can host the static web app.

### Backend (optional)
Requires Python 3.11+.

```bash
cd server
python -m venv .venv
# activate the environment, then:
pip install -r requirements.txt
cp .env.example .env
# Add your provider key and model settings to .env
uvicorn app:app --host 0.0.0.0 --port 8000
```

Never put provider API keys in `web/` or commit `.env`. The backend currently exposes a small, bounded planning endpoint; expand it only with reviewed tools and auth before public deployment.

## Deploy the phone UI
1. Create a GitHub repository named `aster-autonomous-ai`.
2. Upload the contents of this folder.
3. In repository Settings → Pages, deploy from the `main` branch and `/web` folder (or move the web files to the root).
4. Open the published HTTPS URL on Android Chrome → menu → **Add to Home screen**.

For a backend that can use an LLM, deploy `server/` to a Python host and set environment variables there. Do not deploy an unauthenticated backend with private memory or powerful tools.

## Safety model
- Planning and execution are separate steps.
- Tool calls are allow-listed and schema-validated.
- Destructive, external, or high-impact actions should require a confirmation step.
- The user can pause the agent and clear local memory.
- No arbitrary code execution, shell, account access, purchases, messaging, or deletion is enabled by default.
